import React, { Component } from 'react';
import studentId from 'uuid';
import $ from 'jquery';
import StudentList from './StudentList';
import AddStudent from './AddStudent';
import StudentListHeader from './studentListHeader';

class Students extends Component{
	constructor(){
		super();
		this.state = {
			students : [
				{
					id: studentId.v4(),
					name: 'Satyam Prajapati',
					sub: 'B.Tech'
				},
				{
					id: studentId.v4(),
					name: 'Sonu Prajapati',
					sub: 'Civil Engineering'
				},
				{
					id: studentId.v4(),
					name: 'Raja Prajapati',
					sub: 'MBA'
				}

			]
		}
	}

	componentDidMount(){
		this.getJSONData();
	}

	handleNewStudent(newstudent){

		let newSudent = this.state.students;
		newSudent.push(newstudent);
		this.setState({students:newSudent});
	}


	handleDeleteStudent(id){

		let deleteSudent = this.state.students;
		let index = deleteSudent.findIndex(i => i.id == id);
		deleteSudent.splice(index,1);
		this.setState({students:deleteSudent});
	}

	getJSONData(){
		$.ajax({
			url: 'http://localhost:3003/src/data.json',
			dataType: 'json',
			cache: false,
			success: function(data){
				console.log(data);	
			}
		});
	}

	render(){
		let studentList;
		if(this.state.students){
			studentList = this.state.students.map( student => {
				return(
					<StudentList onDelete={this.handleDeleteStudent.bind(this)} student={ student }/>
				);				
			});
		}
		
		return(
			<div className="sm-container">
				<AddStudent addStudent={this.handleNewStudent.bind(this)}/>

				<div className="students">
					<h3>Student List</h3>
					<table className="table table-bordered students-list">
						<StudentListHeader />
						<tbody>
							{ studentList }
						</tbody>
					</table>
				</div>
			</div>
			
		);
	}
}

export default Students;