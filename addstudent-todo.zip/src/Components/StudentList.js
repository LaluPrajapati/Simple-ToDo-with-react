import React, { Component } from 'react';

class StudentList extends Component{
	
	deleteData(id){
		this.props.onDelete(id);
	}

	render(){
		
		return(
			<tr>
				<td> {this.props.student.name} </td>
				<td> {this.props.student.sub} </td>
				<td> <a href="#" onClick={this.deleteData.bind(this, this.props.student.id)}> Delete </a> </td>
			</tr>
		);
	}
}

export default StudentList;