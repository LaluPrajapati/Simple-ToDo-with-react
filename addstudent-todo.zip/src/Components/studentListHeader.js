import React, { Component } from 'react';


class StudentsListHeader extends Component{
	render(){
		return(
			<thead>
				<tr>
					<td>Name</td>
					<td>Subject</td>
					<td>Action</td>
				</tr>
			</thead>
		);
	}
}

export default StudentsListHeader;