import React, { Component } from 'react';
import studentId from 'uuid';

class AddStudent extends Component{
	constructor(){
		super();
		this.state = {
			addNewStudent: {

			}
		}
	}

	handleSubmit(e){
		e.preventDefault();
		if(this.refs.name.value != ''){
			this.setState(
				{
					addNewStudent:{
						id : studentId.v4(),
						name : this.refs.name.value,
						sub : this.refs.subject.value
					}
				}, function(){
					//console.log(this.state);
					this.props.addStudent(this.state.addNewStudent);
					this.refs.name.value = '';
				}
			);
		}
		else {
			alert('Value Required');
		}
	}



	render(){

		let subjects = ['B.Com','BBA','BCA','BSc','B.Tech','M.Com','MBA','MCA','MSc','M.Tech'];
		let subjectList = subjects.map( sub => {
			return <option> { sub } </option>
		});

		return(
			<div className="add-students">
				<h3>Add Student</h3>

				<form onSubmit={this.handleSubmit.bind(this)}>
					<table>
						<tr>
							<td><label>Name:</label></td>
							<td><input type="text" ref="name" /></td>
						</tr>
						<tr>
							<td><label>Subject:</label></td>
							<td>
								<select ref="subject">
									{ subjectList }									
								</select>
							</td>
						</tr>
						<tr>
							<td></td>
							<td><input type="submit" value="Submit" /></td>
						</tr>
					</table>
				</form>			
			</div>
		);
	}
}

export default AddStudent;